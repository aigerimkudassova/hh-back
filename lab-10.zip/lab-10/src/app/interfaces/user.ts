export interface User {
    token: string
}
