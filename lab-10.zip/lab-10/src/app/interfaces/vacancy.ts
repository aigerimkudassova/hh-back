export interface Vacancy {
}
